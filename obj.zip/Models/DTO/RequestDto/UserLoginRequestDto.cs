﻿namespace MALON_GLOBAL_WEBAPP.Models.DTO.RequestDto
{
    public class UserLoginRequestDto
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }

}
