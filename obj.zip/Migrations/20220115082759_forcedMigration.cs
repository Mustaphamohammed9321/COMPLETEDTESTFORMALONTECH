﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace MALON_GLOBAL_WEBAPP.Migrations
{
    public partial class forcedMigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
